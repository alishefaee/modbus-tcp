const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');

const app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// create a tcp modbus client|master
const Modbus = require('jsmodbus')
const net = require('net')
const socket = new net.Socket()
const client = new Modbus.client.TCP(socket, 0x0)

//functions
const {getDeviceName} = require('./functions/readInput')
const {readDI, readDO} = require('./functions/readCoil')
const {turnOnLED,turnOffLED,blinkingLED} = require('./functions/writeCoil')

const options = {
    'host' : '192.168.1.105',
    'port' : 502,
    'debug': true
}

// for reconnecting see node-net-reconnect npm module

// use socket.on('open', ...) when using serialport
socket.on('connect', function () {

    console.log("socket is connected")
    readDI(client)
    readDO(client)
    // turnOffLED(client,socket)
    // turnOnLED(client,socket)
    // blinkingLED(client,socket)
    // getDeviceName(client)

});

socket.connect(options)

module.exports = app;
