exports.getDeviceName = (client) => {
    client.readInputRegisters(5024, 3).then(function (resp) {

// resp will look like { response : [TCP|RTU]Response, request: [TCP|RTU]Request }
// the data will be located in resp.response.body.coils: <Array>, resp.response.body.payload: <Buffer>

        console.log(JSON.stringify(resp));

    }, console.error);
}