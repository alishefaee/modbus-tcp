exports.turnOffLED = (client, socket) => {
    client.writeSingleCoil(0, false)
        .then(function (resp) {
            // console.log(resp)
            // socket.end()
        }).catch(function () {
        console.error(arguments)
        socket.end()
    })
}

exports.turnOnLED = (client, socket) => {
    client.writeSingleCoil(0, true)
        .then(function (resp) {
            // console.log(resp)
            // socket.end()
        }).catch(function () {
        console.error(arguments)
        socket.end()
    })
}

exports.blinkingLED = (client, socket) => {
    let status = true
    setInterval(function () {
        status = !status
        client.writeSingleCoil(1, status)
            .then(function (resp) {
                // console.log(resp)
                // socket.end()
            }).catch(function () {
            console.error(arguments)
            socket.end()
        })
    }, 1000)
}